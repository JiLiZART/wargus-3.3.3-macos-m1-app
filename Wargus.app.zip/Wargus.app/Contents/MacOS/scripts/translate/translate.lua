LanguageTable = {
	"English", "", "",
	"Italian", "scripts/translate/stratagus-it.po", "scripts/translate/it_IT.po",
	"Spanish", "scripts/translate/stratagus-es.po", "scripts/translate/es_ES.po",
	"Russian", "scripts/translate/stratagus-ru.po", "scripts/translate/ru_RU.po",
	"French", "scripts/translate/stratagus-fr.po", "scripts/translate/fr_FR.po",
	"German", "scripts/translate/stratagus-de.po", "scripts/translate/de_DE.po",
	"Czech", "scripts/translate/stratagus-cz.po", "scripts/translate/cz_CZ.po",
}
