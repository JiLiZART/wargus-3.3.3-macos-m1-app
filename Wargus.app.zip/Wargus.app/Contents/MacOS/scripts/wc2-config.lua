wargus.expansion = true
wargus.music_extension = ".mid"
wargus.bne = false
wargus.game_font_width = 13
